package com.sumerge.mlsd.xom.socialcare;

import java.util.ArrayList;
import java.util.List;

import com.sumerge.mlsd.xom.socialcare.HandicappedApplicant.AssistanceCards;

public class AssistanceCardsRequest {

	private List<AssistanceCards> requestedAssistanceCards = new ArrayList<>();

	public AssistanceCardsRequest() {
		/*
		 * Empty Constructor for NULL Avoidance
		 */
	}

	public List<AssistanceCards> getRequestedAssistanceCards() {
		return requestedAssistanceCards;
	}

	public void setRequestedAssistanceCards(List<AssistanceCards> requestedAssistanceCards) {
		this.requestedAssistanceCards = requestedAssistanceCards;
	}

}
