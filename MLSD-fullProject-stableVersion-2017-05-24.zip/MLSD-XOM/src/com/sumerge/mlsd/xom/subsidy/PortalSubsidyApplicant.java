package com.sumerge.mlsd.xom.subsidy;

import com.sumerge.mlsd.xom.common.Applicant;

public class PortalSubsidyApplicant extends Applicant {

	public PortalSubsidyApplicant() {
	}
}
