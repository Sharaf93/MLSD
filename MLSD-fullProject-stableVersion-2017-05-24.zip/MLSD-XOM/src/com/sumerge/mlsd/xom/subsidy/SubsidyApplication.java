package com.sumerge.mlsd.xom.subsidy;

import java.util.Calendar;

import com.sumerge.mlsd.utilities.Utilities;

public class SubsidyApplication {

	public enum ApplicantType {
		HOH, DEPENDENT
	}

	public enum ProfileFlag {
		FIRST, SECOND, NONE
	}

	private ApplicantType applicantTypeInFirstApplication = ApplicantType.HOH;
	private ApplicantType applicantTypeInSecondApplication = ApplicantType.HOH;

	private Calendar firstProfileRegistrationDate = Calendar.getInstance();
	private Calendar secondProfileRegistrationDate = Calendar.getInstance();

	public ApplicantType getApplicantTypeInFirstApplication() {
		return applicantTypeInFirstApplication;
	}

	public void setApplicantTypeInFirstApplication(ApplicantType firstApplicationtype) {
		this.applicantTypeInFirstApplication = firstApplicationtype;
	}

	public ApplicantType getApplicantTypeInSecondApplication() {
		return applicantTypeInSecondApplication;
	}

	public void setApplicantTypeInSecondApplication(ApplicantType secondApplicationtype) {
		this.applicantTypeInSecondApplication = secondApplicationtype;
	}

	public Calendar getFirstProfileRegistrationDate() {
		return firstProfileRegistrationDate;
	}

	public void setFirstProfileRegistrationDate(Calendar firstProfileRegistrationDate) {
		this.firstProfileRegistrationDate = firstProfileRegistrationDate;
	}

	public Calendar getSecondProfileRegistrationDate() {
		return secondProfileRegistrationDate;
	}

	public void setSecondProfileRegistrationDate(Calendar secondProfileRegistrationDate) {
		this.secondProfileRegistrationDate = secondProfileRegistrationDate;
	}

	public boolean firstProfileIsNewer() {
		Calendar firstProfileDate = this.getFirstProfileRegistrationDate();
		Calendar secondProfileDate = this.getSecondProfileRegistrationDate();
		int days = 0;
		days = Utilities.daysBetween(secondProfileDate.getTime(), firstProfileDate.getTime());
		return days > 0;
	}

	public boolean secondProfileIsNewer() {
		if (firstProfileIsNewer() == true)
			return false;
		else
			return true;

	}

}
