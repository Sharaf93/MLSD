package com.sumerge.mlsd.xom;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
//import org.joda.time.DateTime;


import com.sumerge.ummalqura.calendar.UmmalquraCalendar;

public class Utilities {
	
	private static ArrayList<String> acceptedMessages;
	private static ArrayList<String> rejectedMessages = new ArrayList<String>();
	
	private static Calendar testHijriDate;
	
	public Utilities(){}	
	public Utilities(ArrayList<String> acceptedMessages,ArrayList<String> rejectedMessages) {
		super();
		Utilities.acceptedMessages = acceptedMessages;
		Utilities.rejectedMessages = rejectedMessages;
	}
	
	public static ArrayList<String> getAcceptedMessages() {
		return Utilities.acceptedMessages;
	}
	public static void setAcceptedMessages(ArrayList<String> acceptedMessages) {
		Utilities.acceptedMessages = acceptedMessages;
	}
	public static ArrayList<String> getRejectedMessages() {
		return Utilities.rejectedMessages;
	}
	public  static void setRejectedMessages(ArrayList<String> rejectedMessages) {
		Utilities.rejectedMessages = rejectedMessages;
	}

    public static String getAttributeName(String fullMsg){
    	String attrName;
    	String[] fullMsgSplitted = fullMsg.split(" ");
    	attrName = fullMsgSplitted[fullMsgSplitted.length - 1];
    	return attrName;
    }
    
    public static ArrayList<SourceMapper> getAllSourceMappers(Person person){
    	ArrayList<SourceMapper> completeSourceMapper = new ArrayList<SourceMapper>();
    	
    	ArrayList<SourceMapper>	applicantSM = person.getSourcesMap();
    	ArrayList<SourceMapper> benefitDetailsSM = person.getBenefitDetails().getSourcesMap();
    	ArrayList<SourceMapper> imprisonmentSM = person.getImprisonment().getSourcesMap();
    	ArrayList<SourceMapper> medicalConditionSM = person.getMedicalCondition().getSourcesMap();
    	ArrayList<SourceMapper> residencySM = person.getResidencyOutsideKSA().getSourcesMap();
    	ArrayList<SourceMapper> vitalityDetailsSM = person.getVitalityStatus().getSourcesMap();
    	
    	completeSourceMapper.addAll(applicantSM);
    	completeSourceMapper.addAll(benefitDetailsSM);
    	completeSourceMapper.addAll(imprisonmentSM);
    	completeSourceMapper.addAll(medicalConditionSM);
    	completeSourceMapper.addAll(residencySM);
    	completeSourceMapper.addAll(vitalityDetailsSM);
    	
    	return completeSourceMapper;
    }
    
    public static ArrayList<String> getAllDataSources(String attrName, Person person){
    	ArrayList<String> allDataSources = new ArrayList<String>();
    	ArrayList<SourceMapper> completeSourceMapper = Utilities.getAllSourceMappers(person);
    	String tempAttr;
    	if(completeSourceMapper != null){
    		for (SourceMapper sourceMapper : completeSourceMapper) {
    			tempAttr = sourceMapper.getAttributeName();
				if(tempAttr.equals(attrName)){
					allDataSources.add(sourceMapper.getUsedDataSource());
				}
			}
    	}
    	return allDataSources;
    }
    
    public static String generateFullMessage(String msg, ArrayList<String> dataSources){
//    	String[] msgArray = msg.split(" ");
//    	String fullMsg = "";
//    	for(int i=0; i<msgArray.length-1; i++){
//    		fullMsg += msgArray[i] + " ";
//    	}
//    	fullMsg += " According to: ";
//    	for(int i=0; i<dataSources.size(); i++){
//    		fullMsg += dataSources.get(i) + " ";
//    	}
    	return msg;
    }
    public static String returnFullMsg(String msg, Applicant applicant)
    {
//    	String attrName = Utilities.getAttributeName(msg);
//    	ArrayList<String> usedDataSources = Utilities.getAllDataSources(attrName, applicant);
//    	String fullMsg = Utilities.generateFullMessage(msg,usedDataSources);
    	return msg;
    }
    public static String AddToRejectedMessages(String msg, Person person){
      	 
    	String attrName = Utilities.getAttributeName(msg);
    	ArrayList<String> usedDataSources = Utilities.getAllDataSources(attrName, person);
    	String fullMsg = Utilities.generateFullMessage(msg,usedDataSources);
    	
    	return fullMsg;
//    	System.out.println("The Full Message: " + fullMsg);
//    	messageList.add(fullMsg);
////    	
//    	ArrayList<String> rejectionList = getRejectedMessages();
//    	ArrayList<String> tempArr = new ArrayList<String>();
//    	
//    	if(rejectionList == null){
//    		tempArr.add(fullMsg);
//    		
//    	}else{
//    		tempArr = rejectionList;
//    		tempArr.add(fullMsg);
//    	}
//    	setRejectedMessages(tempArr);
    }
    
    //////////////////////////// Hijri Functions /////////////////////////////////////
    public static Calendar getTestHijriDate() {
    	Calendar tempTestHijriDate = Utilities.getHijriDateFromGregorianDate(testHijriDate);
		int year = testHijriDate.get(Calendar.YEAR);
		int month = testHijriDate.get(Calendar.MONTH);
		int day = testHijriDate.get(Calendar.DAY_OF_MONTH);

		return testHijriDate;
	}
    
	public static void setTestHijriDate(Calendar testHijriDate) {
		Calendar cal = new UmmalquraCalendar();
		int year = testHijriDate.get(Calendar.YEAR);
    	int month = testHijriDate.get(Calendar.MONTH);
    	int day = testHijriDate.get(Calendar.DAY_OF_MONTH);
    	
    	cal.set(Calendar.YEAR, year);
    	cal.set(Calendar.MONTH, month);
    	cal.set(Calendar.DAY_OF_MONTH, day);
    	
		Utilities.testHijriDate.setTime(cal.getTime());
	}
	
    public static Calendar getGregorianDateFromHijriDate(Calendar hijriDate){
    	int hijriYear = hijriDate.get(Calendar.YEAR);
    	int hijriMonth = hijriDate.get(Calendar.MONTH);
    	int hijriDay = hijriDate.get(Calendar.DAY_OF_MONTH);
    	Calendar uCal = new UmmalquraCalendar(hijriYear, hijriMonth, hijriDay);
    	
    	return uCal;
    }
    
    public static Calendar getHijriDateFromGregorianDate(Calendar gregorianDate){
    	
    	Calendar cal = new UmmalquraCalendar();
    	cal.setTime(gregorianDate.getTime());
    	return cal;
    }
    
    public static Calendar getTodaysHigriDate(){
    	UmmalquraCalendar cal = new UmmalquraCalendar();
    	cal.get(Calendar.YEAR);         
    	cal.get(Calendar.MONTH);        
    	cal.get(Calendar.DAY_OF_MONTH);
    	
    	return cal;
    }
    
    // Pattern: (yyyy,mmmm,dd) Ex:(1438 Rab-II 9)
    public static String getHijriDateAsString(Calendar hijriDate){
    	String hijriDateString = "";
    	int hijriMonthNumber = hijriDate.get(Calendar.MONTH)+1;
    	hijriDateString += hijriDate.get(Calendar.YEAR);
    	hijriDateString += " " + hijriDate.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH);
    	hijriDateString += "(" + hijriMonthNumber + ")";
    	hijriDateString += " " + hijriDate.get(Calendar.DAY_OF_MONTH);
    	
    	return hijriDateString;
    }
    
    public static int getNumberOfDaysBetweenTwoHijriDates(Calendar startCal, Calendar endCal){
    	
    	Calendar start = Calendar.getInstance();
        start.setTimeZone(startCal.getTimeZone());
        start.setTimeInMillis(startCal.getTimeInMillis());

        Calendar end = Calendar.getInstance();
        end.setTimeZone(endCal.getTimeZone());
        end.setTimeInMillis(endCal.getTimeInMillis());

        start.set(Calendar.HOUR_OF_DAY, 0);
        start.set(Calendar.MINUTE, 0);
        start.set(Calendar.SECOND, 0);
        start.set(Calendar.MILLISECOND, 0);

        end.set(Calendar.HOUR_OF_DAY, 0);
        end.set(Calendar.MINUTE, 0);
        end.set(Calendar.SECOND, 0);
        end.set(Calendar.MILLISECOND, 0);

        return (int) (TimeUnit.MILLISECONDS.toDays(end.getTimeInMillis() - start.getTimeInMillis()));
    }
    /////////////////////////////////////////////////////////////////////////////////////
   
    /////////////////////////////////////////////////////////////////////////////////////
//    public static void main(String[] args){
//    	
//    	////// From Hijri To Gregorian /////////
//    	Calendar cal = Calendar.getInstance();
//    	cal.set(Calendar.YEAR, 1438);
//    	cal.set(Calendar.MONTH, 4);
//    	cal.set(Calendar.DAY_OF_MONTH, 10);
//    	Calendar gregorian = Utilities.getGregorianDateFromHijriDate(cal);
////    	System.out.println("From Hijri to Gregorian Date: " + gregorian.getTime());
//    	//Console: From Hijri to Gregorian Date: Sat Jan 07 00:00:00 EET 2017
//    	
//    	//// From Gregorian To Hijri ////////////
//    	Calendar gCal = Calendar.getInstance();
//    	gCal.set(Calendar.YEAR, 2016);
//    	gCal.set(Calendar.MONTH, 12);
//    	gCal.set(Calendar.DAY_OF_MONTH, 5);
//    	Calendar toHijri = Utilities.getHijriDateFromGregorianDate(gCal);
//    	String hijriDateAgain = Utilities.getHijriDateAsString(toHijri);
////    	System.out.println("From Gregorian To Hijri Date: " + hijriDateAgain);
//    	//Console: From Gregorian To Hijri Date: 1438 Rab-II 9
//    	
//    	////// Today's Hijri Date //////////////
//    	Calendar today = Utilities.getTodaysHigriDate();
//    	String hijriWrittenDate = Utilities.getHijriDateAsString(today);
////    	System.out.println("Todays Hijri Date: " + hijriWrittenDate);
//    	//Console: Todays Hijri Date: 1438 Rab-II 9
//    	
//    	
//    	///// Difference Between Two Hijri Dates in Days//////
//    	Calendar today2 = Utilities.getTodaysHigriDate();
//    	Calendar cal2 = new UmmalquraCalendar();
//    	cal2.set(Calendar.YEAR, 1438);
//    	cal2.set(Calendar.MONTH, 11);
//    	cal2.set(Calendar.DAY_OF_MONTH, 9);
//    	int noofdays = Utilities.getNumberOfDaysBetweenTwoHijriDates(cal2,today2);
////    	System.out.println("Difference in Days: " + noofdays);
//
//    	////////////////// Test  Hijri Date ///////////////////
////    	DateTime dt = new DateTime();
//    	Calendar testIt = new UmmalquraCalendar();
//    	String printHijri = Utilities.getHijriDateAsString(testIt);
////    	System.out.println("Test Hijri Date: (1): " + printHijri);
//    	Utilities.setTestHijriDate(testIt);
//    	printHijri = Utilities.getHijriDateAsString(Utilities.getTestHijriDate());
////    	System.out.println("Test Hijri Date: (2): " + printHijri);
//    }
    
    public void addTo(String msg){
    	Utilities.getRejectedMessages().add(msg) ;   	
    }
    public static void addTestMessage(ArrayList<String> testArray){
    	testArray = new ArrayList<String>(); 
    	testArray.add("input is out");
    }
	
}