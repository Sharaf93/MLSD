package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Calendar;

import com.sumerge.ummalqura.calendar.UmmalquraCalendar;

public class MedicalCondition {
	
	private String illnessName = "";
	private boolean terminalIllness = false;
	private boolean permenantDisability = false;
	private boolean temporaryDisability = false;
	private boolean temporaryIllness = false;
	private Calendar medicalReportDate = Calendar.getInstance();
	private int medicationPeriod = 0;
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();

	public MedicalCondition(){}
	public MedicalCondition(/*@BusinessName("typeOfIllness") String typeOfIllness,*/ @BusinessName("terminallyIll") boolean terminallyIll,
			@BusinessName("permenantDisability")boolean disabledPermenantly, @BusinessName("temporaryDisability") boolean disabledTemporarily,
			@BusinessName("medicalReportDate") Calendar medicalReportDate, @BusinessName("recoveryTimeInDays") int recoveryTimeInDays,
			@BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
//		this.typeOfIllness = typeOfIllness;
		this.terminalIllness = terminallyIll;
		this.permenantDisability = disabledPermenantly;
		this.temporaryDisability = disabledTemporarily;
		this.medicalReportDate = medicalReportDate;
		this.medicationPeriod = recoveryTimeInDays;
		this.sourcesMap = sourcesMap;
	}

	public String getillnessName() {
		return illnessName;
	}

	public void setillnessName(String typeOfIllness) {
		this.illnessName = typeOfIllness;
	}

	public boolean isTerminallyIll() {
		return terminalIllness;
	}
	
	public boolean isNotTerminallyIll(){
		boolean terminally = this.isTerminallyIll();
		if(terminally == false){
			return true;
		}
		return false;
	}

	public void setTerminallyIll(boolean terminallyIll) {
		this.terminalIllness = terminallyIll;
	}

	public boolean isPermenantDisability() {
		return permenantDisability;
	}
	
	public boolean isNotPermenantDisability(){
		boolean permenant = this.isPermenantDisability();
		if(permenant == false){
			return true;
		}
		return  false;
	}

	public void setPermenantDisability(boolean disabledPermenantly) {
		this.permenantDisability = disabledPermenantly;
	}

	public boolean istemporaryDisability() {
		return temporaryDisability;
	}

	public void settemporaryDisability(boolean disabledTemporarily) {
		this.temporaryDisability = disabledTemporarily;
	}

	public Calendar getMedicalReportDate() {
		Calendar medicalReportDateHijriDate = Utilities.getHijriDateFromGregorianDate(medicalReportDate);
		int year = medicalReportDateHijriDate.get(Calendar.YEAR);
		int month = medicalReportDateHijriDate.get(Calendar.MONTH);
		int day = medicalReportDateHijriDate.get(Calendar.DAY_OF_MONTH);

		return medicalReportDateHijriDate;
	}

	public void setMedicalReportDate(Calendar medicalReportDate) {
		Calendar cal = new UmmalquraCalendar();
		int year = medicalReportDate.get(Calendar.YEAR);
    	int month = medicalReportDate.get(Calendar.MONTH);
    	int day = medicalReportDate.get(Calendar.DAY_OF_MONTH);
    	
    	cal.set(Calendar.YEAR, year);
    	cal.set(Calendar.MONTH, month);
    	cal.set(Calendar.DAY_OF_MONTH, day);
    	
		this.medicalReportDate.setTime(cal.getTime());
	}

	public int getMedicationPeriod() {
		return medicationPeriod;
	}

	public void setMedicationPeriod(int recoveryTimeInDays) {
		this.medicationPeriod = recoveryTimeInDays;
	}

	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}

	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	public boolean isTemporaryIllness() {
		return temporaryIllness;
	}
	public void setTemporaryIllness(boolean temporaryIllness) {
		this.temporaryIllness = temporaryIllness;
	}
	
	
}
