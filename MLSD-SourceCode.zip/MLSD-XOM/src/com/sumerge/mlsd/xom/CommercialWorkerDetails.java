package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Date;


public class CommercialWorkerDetails {

	private String workType = "";
	private String workerName = "";
	private Date hireDate = new Date();
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();


	
	public CommercialWorkerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommercialWorkerDetails(@BusinessName("workerName") String workerName,
			@BusinessName("hireDate") Date hiringDate, @BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.workerName = workerName;
		this.hireDate = hiringDate;
		this.sourcesMap = sourcesMap;
	}

	public String getWorkType() {
		return workType;
	}

	public void setWorkType(String workType) {
		this.workType = workType;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hiringDate) {
		this.hireDate = hiringDate;
	}

	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}

	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	
	
}
