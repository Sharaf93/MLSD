package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;

public class AssetDetails {
	
	public enum RealStateType{
		Villa, Apartment, Building, Other
	}
	private int areaInSquaredMeters = 0;
	private String assetType = "";              // villa ... apartment ... building
	private boolean  isResidential = false;              // Residential ... commercial
	private boolean isShared = false;
	private Double assetValueInSAR = 0.0;
	private String assetSource = "";     // inherited ... granted from state ... other
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();

	public AssetDetails(){}
	public AssetDetails(@BusinessName("area") int area,/* @BusinessName("type")String type,*/ @BusinessName("commercial") boolean commercial,
			@BusinessName("assetValueInSAR") Double assetValueInSAR, @BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.areaInSquaredMeters = area;
//		this.type = type;
		this.isResidential = commercial;
//		this.assetSource = sourceOfAsset;
		this.assetValueInSAR = assetValueInSAR;
		this.sourcesMap = sourcesMap;
	}	

	public int getArea() {
		return areaInSquaredMeters;
	}

	public void setArea(int area) {
		this.areaInSquaredMeters = area;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String type) {
		this.assetType = type;
	}

	public boolean isCommercial() {
		return isResidential;
	}

	public void setCommercial(boolean commercial) {
		this.isResidential = commercial;
	}

	public String getSourceOfAsset() {
		return assetSource;
	}

	public void setSourceOfAsset(String sourceOfAsset) {
		this.assetSource = sourceOfAsset;
	}

	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}

	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}

	public boolean isShared() {
		return isShared;
	}

	public void setShared(boolean isShared) {
		this.isShared = isShared;
	}
	public Double getAssetValueInSAR() {
		return assetValueInSAR;
	}
	public void setAssetValueInSAR(Double assetValueInSAR) {
		this.assetValueInSAR = assetValueInSAR;
	}
	
	public boolean isNotShared(){
		boolean shared = this.isShared;
		if(shared){
			return false;
		}
		return true;
	}
	public boolean isNotCommercial(){
		boolean commercial = this.isCommercial();
		if(commercial){
			return false;
		}
		return true;
	}

///////////////////////////// Getters And Setters ///////////////////////////////

	
}
