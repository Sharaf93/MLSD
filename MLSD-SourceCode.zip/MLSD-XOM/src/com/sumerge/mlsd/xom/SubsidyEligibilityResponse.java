package com.sumerge.mlsd.xom;

public class SubsidyEligibilityResponse {
	
	
	private boolean eligibility = false ;
	private String eligibilityText = "" ;
	
	
	
	public SubsidyEligibilityResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SubsidyEligibilityResponse(boolean eligibility,
			String eligibilityText) {
		super();
		this.eligibility = eligibility;
		this.eligibilityText = eligibilityText;
	}
	public boolean isEligibility() {
		return eligibility;
	}
	public void setEligibility(boolean eligibility) {
		this.eligibility = eligibility;
		this.setEligibilityText("eligiblity: "+eligibility+"");		
	}
	public String getEligibilityText() {
		return eligibilityText;
	}
	public void setEligibilityText(String eligibilityText) {
		this.eligibilityText = eligibilityText;
	} 
	public void markAsEligible() {
		this.eligibility = true;
	}
	public void markAsNotEligible() {
		this.eligibility = false;
	} 


}
