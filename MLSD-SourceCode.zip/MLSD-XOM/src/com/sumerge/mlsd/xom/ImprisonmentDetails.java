package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Date;

public class  ImprisonmentDetails {
	
	
	public enum CrimeType{
		felony, misdemeanor
	}
	
	private boolean imprisoned = false;
	private int sentenceDurationInDays = 0;
	private Date imprisonmentDate = new Date();
	private Date releaseDate = new Date();
	private Date imprisonmentReportDate = new Date();
	private CrimeType crimeType;
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	

	public ImprisonmentDetails(){}
	public ImprisonmentDetails(/*@BusinessName("isInPrison") boolean isInPrison,*/ @BusinessName("sentenceDurationInDays") int sentenceDurationInDays,
			@BusinessName("imprisonmentDate") Date imprisonmentDate, @BusinessName("releaseDate") Date releaseDate, @BusinessName("crimeType") CrimeType crimeType,
			@BusinessName("imprisonmentReportDate") Date imprisonmentReportDate,@BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
//		this.isInPrison = isInPrison;
		this.sentenceDurationInDays = sentenceDurationInDays;
		this.setImprisonmentDate(imprisonmentDate);
		this.releaseDate = releaseDate;
		this.imprisonmentReportDate = imprisonmentReportDate;
		this.crimeType = crimeType;
		this.sourcesMap = sourcesMap;
	}
	public boolean isimprisoned() {
		return imprisoned;
	}
	public boolean isNotImprisoned() {
		return !imprisoned;
	}
	public void setimprisoned(boolean isImprisoned) {
		this.imprisoned = isImprisoned;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public int getSentenceDurationInDays() {
		return sentenceDurationInDays;
	}
	public void setSentenceDurationInDays(int sentenceDurationInDays) {
		this.sentenceDurationInDays = sentenceDurationInDays;
	}
	public CrimeType getCrimeType() {
		return crimeType;
	}
	public void setCrimeType(CrimeType crimeType) {
		this.crimeType = crimeType;
	}
	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}
	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	public Date getImprisonmentDate() {
		return imprisonmentDate;
	}
	public void setImprisonmentDate(Date imprisonmentDate) {
		this.imprisonmentDate = imprisonmentDate;
	}
	public Date getImprisonmentReportDate() {
		return imprisonmentReportDate;
	}
	public void setImprisonmentReportDate(Date imprisonmentReportDate) {
		this.imprisonmentReportDate = imprisonmentReportDate;
	}
	
	

}
