package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Date;

public class ResidencyDetailsOutsideKSA {
	

	private Date residencyPermenancyApprovalDate = new Date();
	private String reasonForTemporaryResidency = "";
	private int noOfDaysOutsideKSA = 0;	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	////////////////////////////////////////////////////////////////
	
	public ResidencyDetailsOutsideKSA(){}
	public ResidencyDetailsOutsideKSA(@BusinessName("residencyPermenancyApprovalDate") Date residencyPermenancyApprovalDate,
			@BusinessName("reasonForTemporaryResidency") String reasonForTemporaryResidency,@BusinessName("number of days outside KSA") int noOfDaysOutsideKSA,
			@BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.residencyPermenancyApprovalDate = residencyPermenancyApprovalDate;
		this.reasonForTemporaryResidency = reasonForTemporaryResidency;
		this.noOfDaysOutsideKSA = noOfDaysOutsideKSA;
		this.setSourcesMap(sourcesMap);
	}
	
	public Date getReasonValidityDate() {
		return residencyPermenancyApprovalDate;
	}
	public void setReasonValidityDate(Date reasonValidityDate) {
		this.residencyPermenancyApprovalDate = reasonValidityDate;
	}
	public String getReasonForTemporaryResidency() {
		return reasonForTemporaryResidency;
	}
	public void setReasonForTemporaryResidency(String reasonForTemporaryResidency) {
		this.reasonForTemporaryResidency = reasonForTemporaryResidency;
	}
	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}
	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}	
	
	//////////////////////////////////////// Added Functions //////////////////////////////

	public boolean TheReasonValidityDateForTheApprovalDidNotExceedOneYear()
	{
		return false;
	}
	public int getNoOfDaysOutsideKSA() {
		return noOfDaysOutsideKSA;
	}
	public void setNoOfDaysOutsideKSA(int noOfDaysOutsideKSA) {
		this.noOfDaysOutsideKSA = noOfDaysOutsideKSA;
	}
	
}
