package com.sumerge.mlsd.xom;

import java.util.ArrayList;
import java.util.List;

public class DependentsInformation {
	List<Person> dependentsList = new ArrayList<Person>() ;
	
	public DependentsInformation(){}

	public List<Person> getDependentsList() {
		if(this.dependentsList == null)
		{
			this.dependentsList = new ArrayList<Person>();
		}
		return this.dependentsList;
	}

	public void setDependentsList(List<Person> dependentsList) {
		this.dependentsList = dependentsList;
	}
	

}
