package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Date;

public class VitalityDetails {
	
	private boolean isDeceased = false;
	private Date deceasedDate = new Date();
	private Date dateOfBirth = new Date();
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	
	/////////////////////////////////////////////////////////////////
	
	public VitalityDetails(){}
	public VitalityDetails(/*@BusinessName("isDeceased") boolean isDeceased,*/ @BusinessName("deceasedDate") Date deceasedDate,
			@BusinessName("dateOfBirth") Date dateOfBirth, @BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
//		this.isDeceased = isDeceased;
		this.deceasedDate = deceasedDate;
		this.dateOfBirth = dateOfBirth;
		this.sourcesMap = sourcesMap;
	}
	public boolean isDeceased() {
		return isDeceased;
	}

	public void setDeceased(boolean isDeceased) {
		this.isDeceased = isDeceased;
	}



	public Date getDeceasedDate() {
		return deceasedDate;
	}



	public void setDeceasedDate(Date deceasedDate) {
		this.deceasedDate = deceasedDate;
	}



	public Date getDateOfBirth() {
		return dateOfBirth;
	}



	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}



	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	
	
	
}
