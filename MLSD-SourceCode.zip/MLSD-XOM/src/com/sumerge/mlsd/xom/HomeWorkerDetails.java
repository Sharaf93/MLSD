package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Date;


public class HomeWorkerDetails {
	
	public enum WorkType{
		Nurse, Driver, Maid, Gardener, Other
	}
	
	private String workerType = "";
	private String workerName = "";
	private Date hireDate = new Date();
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	
	
	///////////////////////////////////////////////////////////////////////////////
	
	public HomeWorkerDetails(){}
	public HomeWorkerDetails(/*@BusinessName("typeOfWork") String typeOfWork,*/ @BusinessName("dateOfHiring") Date dateOfHiring,
			@BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
//		this.workerType = typeOfWork;
		this.hireDate = dateOfHiring;
		this.sourcesMap = sourcesMap;
	}

	public String getTypeOfWork() {
		return workerType;
	}
	public void setTypeOfWork(String typeOfWork) {
		this.workerType = typeOfWork;
	}
	public Date getDateOfHiring() {
		return hireDate;
	}
	public void setDateOfHiring(Date dateOfHiring) {
		this.hireDate = dateOfHiring;
	}
	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}
	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	public String getWorkerName() {
		return workerName;
	}
	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}
	
		
}
