package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;



public class SourceMapper {
	
	private String attributeName = "";
	private String usedDataSource = "";
	
	
	public SourceMapper(){}
	public SourceMapper(@BusinessName("attributeName") String attributeName,@BusinessName("usedDataSource") String usedDataSource) {
		super();
		this.attributeName = attributeName;
		this.usedDataSource = usedDataSource;
	}
	
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getUsedDataSource() {
		return usedDataSource;
	}
	public void setUsedDataSource(String usedDataSource) {
		this.usedDataSource = usedDataSource;
	}
	
	
	
}
