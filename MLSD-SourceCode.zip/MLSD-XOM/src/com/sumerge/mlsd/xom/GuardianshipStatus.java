package com.sumerge.mlsd.xom;

public class GuardianshipStatus {
	
	
	public enum Relationship{
		Cousin, GrandFather, Father, Mother, Uncle, None
	}
	
	boolean underCustody = false;
	String guardianNIN="";
	Relationship guardianRelationship = Relationship.None;
	
		
	
	public GuardianshipStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GuardianshipStatus(boolean underCustody, String guardianSSN, Relationship guardianRelationship) {
		super();
		this.underCustody = underCustody;
		this.guardianNIN = guardianSSN;
		this.guardianRelationship = guardianRelationship;
	}
	public boolean isUnderCustody() {
		return underCustody;
	}
	public void setUnderCustody(boolean underCustody) {
		this.underCustody = underCustody;
	}
	public String getGuardianNIN() {
		return guardianNIN;
	}
	public void setGuardianNIN(String guardianSSN) {
		this.guardianNIN = guardianSSN;
	}
	public Relationship getGuardianRelationship() {
		return guardianRelationship;
	}
	public void setGuardianRelationship(Relationship guardianRelationship) {
		this.guardianRelationship = guardianRelationship;
	}
	

}
