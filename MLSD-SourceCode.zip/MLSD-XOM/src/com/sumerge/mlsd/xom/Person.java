package com.sumerge.mlsd.xom;
import java.beans.ConstructorProperties;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.sumerge.mlsd.xom.Appeal.AppealType;
import com.sumerge.mlsd.xom.IncomeDetails.IncomeType;


public class Person {
	
	public enum Gender{
		Male, Female
	}
	public enum MaritalStatus{
		Married, UnMarried, Widowed
	}

	private int age = 17;
	private String NIN = "";
	private String ID = "";
	private String IDType = "National ID";
	private int noOfOffsprings = 0;
	
	private String name = "";  // all names combined 
	private Gender gender = Gender.Male;
	private String maritalStatus = "Single";
	private String nationality = "Saudi Arabia"; 


	private boolean livesInGovernmentHouse = false;
	private boolean hasAPrivateBusiness = false;
	private boolean approvedToBeIndependentFromBeneficiary = false;
	private boolean isBlacklisted = false;

	private VitalityDetails vitalityStatus = new VitalityDetails();
	private BenefitDetails benefitDetails = new BenefitDetails();
	private EducationDetails educationDetails = new EducationDetails();
	private PersonalStatusDetails statusDetails = new PersonalStatusDetails();
	private GuardianshipStatus guardianshipstatus = new GuardianshipStatus();
	private ResidencyDetailsOutsideKSA residencyOutsideKSA = new ResidencyDetailsOutsideKSA();
	private ImprisonmentDetails imprisonment = new ImprisonmentDetails() ;
	private MedicalCondition medicalCondition = new MedicalCondition();
	
	private ArrayList<IncomeDetails> incomeDetails = new ArrayList<IncomeDetails>();
	private ArrayList<HomeWorkerDetails> homeWorkers = new ArrayList<HomeWorkerDetails>();
	private ArrayList<CommercialWorkerDetails> commercialWorkers = new ArrayList<CommercialWorkerDetails>();
	private ArrayList<Appeal> appeals = new ArrayList<Appeal>();
	private ArrayList<AssetDetails> assets = new ArrayList<AssetDetails>();
	
	private RejectionMessages rejectionMessages = new RejectionMessages();
	
//	private List<RejectionMessages> RejectionMessagesObjects = new ArrayList<RejectionMessages>(); 
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();

	
	public Person(){}
	@ConstructorProperties({"age","SSN","ID",/*"IDType",*/"name","gender",/*"maritalStatus","nationality",*/
		"livesInGovernmentShelter","hasAPrivateBusiness","approvedToBeIndependentFromBeneficiary",
		"isBlacklisted", "VitalityDetails","vitalityStatus","benefitDetails","educationDetails",
		"statusDetails","residencyOutsideKSA","imprisonment","medicalCondition","incomeDetails","homeWorkers",
		"commercialWorkers","appeals","assets","sourcesMap"}) 
	public Person(int age, String sSN, String iD,/* String iDType,*/ String name,
			Gender gender,/* String maritalStatus, String nationality,*/
			boolean livesInGovernmentShelter, boolean hasAPrivateBusiness,
			boolean approvedToBeIndependentFromBeneficiary,
			boolean isBlacklisted, VitalityDetails vitalityStatus,
			BenefitDetails benefitDetails, EducationDetails profession,
			PersonalStatusDetails statusDetails,
			ResidencyDetailsOutsideKSA residency, ImprisonmentDetails imprisonment,
			MedicalCondition medicalCondition,
			ArrayList<IncomeDetails> employments,
			ArrayList<HomeWorkerDetails> homeWorkers,
			ArrayList<CommercialWorkerDetails> commercialWorkers,
			ArrayList<Appeal> appeals,
			ArrayList<AssetDetails> assets, ArrayList<SourceMapper> sourcesMap) {
		super();
		this.age = age;
		NIN = sSN;
		ID = iD;
//		IDType = iDType;
		this.name = name;
		this.gender = gender;
//		this.maritalStatus = maritalStatus;
//		this.nationality = nationality;
		this.livesInGovernmentHouse = livesInGovernmentShelter;
		this.hasAPrivateBusiness = hasAPrivateBusiness;
		this.approvedToBeIndependentFromBeneficiary = approvedToBeIndependentFromBeneficiary;
		this.isBlacklisted = isBlacklisted;
		this.vitalityStatus = vitalityStatus;
		this.benefitDetails = benefitDetails;
		this.educationDetails = profession;
		this.statusDetails = statusDetails;
		this.residencyOutsideKSA = residency;
		this.imprisonment = imprisonment;
		this.medicalCondition = medicalCondition;
		this.incomeDetails = employments;
		this.homeWorkers = homeWorkers;
		this.commercialWorkers = commercialWorkers;
		this.appeals = appeals;
		this.assets = assets;
		this.sourcesMap = sourcesMap;
	}	
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getNIN() {
		return NIN;
	}

	public void setNIN(String sSN) {
		NIN = sSN;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getIDType() {
		return IDType;
	}

	public void setIDType(String iDType) {
		IDType = iDType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public boolean isLivesInGovernmentHouse() {
		return livesInGovernmentHouse;
	}

	public void setLivesInGovernmentHouse(boolean livesInGovernmentShelter) {
		this.livesInGovernmentHouse = livesInGovernmentShelter;
	}

	public boolean isHasAPrivateBusiness() {
		return hasAPrivateBusiness;
	}

	public void setHasAPrivateBusiness(boolean hasAPrivateBusiness) {
		this.hasAPrivateBusiness = hasAPrivateBusiness;
	}

	public boolean isApprovedToBeIndependentFromBeneficiary() {
		return approvedToBeIndependentFromBeneficiary;
	}

	public void setApprovedToBeIndependentFromBeneficiary(
			boolean approvedToBeIndependentFromBeneficiary) {
		this.approvedToBeIndependentFromBeneficiary = approvedToBeIndependentFromBeneficiary;
	}

	public boolean isBlacklisted() {
		return isBlacklisted;
	}

	public void setBlacklisted(boolean isBlacklisted) {
		this.isBlacklisted = isBlacklisted;
	}

	public VitalityDetails getVitalityStatus() {
		return vitalityStatus;
	}

	public void setVitalityStatus(VitalityDetails vitalityStatus) {
		this.vitalityStatus = vitalityStatus;
	}

	public BenefitDetails getBenefitDetails() {
		return benefitDetails;
	}

	public void setBenefitDetails(BenefitDetails benefitDetails) {
		this.benefitDetails = benefitDetails;
	}

	public EducationDetails getEducationDetails() {
		return educationDetails;
	}

	public void setEducationDetails(EducationDetails profession) {
		this.educationDetails = profession;
	}

	public PersonalStatusDetails getStatusDetails() {
		return statusDetails;
	}

	public void setStatusDetails(PersonalStatusDetails statusDetails) {
		this.statusDetails = statusDetails;
	}

	public ResidencyDetailsOutsideKSA getResidencyOutsideKSA() {
		return residencyOutsideKSA;
	}

	public void setResidencyOutsideKSA(ResidencyDetailsOutsideKSA residency) {
		this.residencyOutsideKSA = residency;
	}

	public ImprisonmentDetails getImprisonment() {
		return imprisonment;
	}

	public void setImprisonment(ImprisonmentDetails imprisonment) {
		this.imprisonment = imprisonment;
	}

	public MedicalCondition getMedicalCondition() {
		return medicalCondition;
	}

	public void setMedicalCondition(MedicalCondition medicalCondition) {
		this.medicalCondition = medicalCondition;
	}
	public ArrayList<IncomeDetails> getIncomeDetails() {
		return incomeDetails;
	}

	public void setIncomeDetails(ArrayList<IncomeDetails> employments) {
		incomeDetails = employments;
	}

	public ArrayList<Appeal> getAppeals() {
		return appeals;
	}
	public void setAppeals(ArrayList<Appeal> appeals) {
		this.appeals = appeals;
	}
	public GuardianshipStatus getGuardianshipstatus() {
		return guardianshipstatus;
	}
	public void setGuardianshipstatus(GuardianshipStatus guardianshipstatus) {
		this.guardianshipstatus = guardianshipstatus;
	}
	public ArrayList<HomeWorkerDetails> getHomeWorkers() {
		return homeWorkers;
	}

	public void setHomeWorkers(ArrayList<HomeWorkerDetails> homeWorkers) {
		this.homeWorkers = homeWorkers;
	}

	public ArrayList<CommercialWorkerDetails> getCommercialWorkers() {
		return commercialWorkers;
	}

	public void setCommercialWorkers(ArrayList<CommercialWorkerDetails> commercialWorkers) {
		this.commercialWorkers = commercialWorkers;
	}



	public ArrayList<AssetDetails> getAssets() {
		return assets;
	}

	public void setAssets(ArrayList<AssetDetails> assets) {
		this.assets = assets;
	}

//	public RejectionMessages getRejectionMessages() {
//		return rejectionMessages;
//	}
//	public void setRejectionMessages(RejectionMessages rejectionMessages) {
//		this.rejectionMessages = rejectionMessages;
//	}
	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}

	public int getNoOfOffsprings() {
		return noOfOffsprings;
	}
	public void setNoOfOffsprings(int noOfOffsprings) {
		this.noOfOffsprings = noOfOffsprings;
	}
	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}

/////////////////////////////////// Added Functions ///////////////////////////////////////////

	public void setRejectionMessage(RejectionMessageDetails rejectionMessage) {

//		String fullMsg = rejectionMessage;
//
//		List<String> rejectionMsgs = rejectionMessages.getRejectionMsg();
//		
//		if(rejectionMsgs == null){
//			rejectionMsgs = new ArrayList<String>();
//		}
//		rejectionMsgs.add(fullMsg);
		
		List<RejectionMessageDetails> rejectionMsgs = rejectionMessages.getRejectionMsg();
		if (rejectionMsgs == null) {
			rejectionMsgs = new ArrayList<RejectionMessageDetails>();
		}
		rejectionMsgs.add(rejectionMessage);
	}

	public boolean incomeTypesDoesNotIncludeAPrivateBusiness()
	{
		List<IncomeDetails> incomeDetails = this.getIncomeDetails();
		if ( incomeDetails != null)
		{
			for (IncomeDetails incomeDetail : incomeDetails) {
				if (incomeDetail.getIncomeType() == IncomeType.PrivateBusiness)
				{
					return false;
				}
				
			}
		}
		
		return true;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public boolean hasRedundentHomeWorkers()
	{
		String first,second,third;
		ArrayList<HomeWorkerDetails> homeWorkers = this.getHomeWorkers();
		if (homeWorkers != null){
			if(homeWorkers.size() == 2){
				first = homeWorkers.get(0).getTypeOfWork();
				second = homeWorkers.get(1).getTypeOfWork();
				if(first == second){
					return true;
				}
			}
			if(homeWorkers.size() == 3){
				first = homeWorkers.get(0).getTypeOfWork();
				second = homeWorkers.get(1).getTypeOfWork();
				third = homeWorkers.get(2).getTypeOfWork();
				if(first == second || first == third || second == third){
					return true;
				}
			}
		}
		return false;
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// rename
	public boolean ReportDateExpirationIsLessThan(int noofdays)
    {
    	int days = daysBetween(Calendar.getInstance().getTime(), this.getStatusDetails().getStatusReportDate().getTime());
    	if (days > noofdays)
    	{
    		return true;
    	}
    	return false;
    }
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public boolean statusReportExpirationCheck(int years)
    {
		Calendar today = Calendar.getInstance();
		Calendar statusReportDate = this.getStatusDetails().getStatusReportDate();
		int reportYear = statusReportDate.get(Calendar.YEAR);
		int expirationYear = reportYear + years;
		statusReportDate.set(Calendar.YEAR, expirationYear);
		
		int daysBetweenTodayAndReportExp = daysBetween(today.getTime(),statusReportDate.getTime());
		if(daysBetweenTodayAndReportExp > 0){
			return false; // Greater than todays date
		}
		return true; // Less than todays date
    }
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public boolean isAlive()
	{
		VitalityDetails vitalityStatus = getVitalityStatus();
		if ( vitalityStatus != null)
		{
			if (!vitalityStatus.isDeceased())
			{
				return true;
			}
		}
		
		return false;
	}
	
    //////////////////////////////////////////////////////////////////////////
    public	boolean hasAValidAbsenceReason()
    {
		ResidencyDetailsOutsideKSA residency = this.getResidencyOutsideKSA();
		if(residency != null ){
			if (residency.getReasonForTemporaryResidency().equals("Accompanying a dependent"))
	    	{
	    		return true;
	    	}
		}
		
    	return false;
    }

    ///////////////////////////////////
    public int daysBetween(Date d1, Date d2){
    	
        return (int)( (d2.getTime() - d1.getTime() ) / (1000 * 60 * 60 * 24));
        
        
}
 // rename
public boolean absenceDurationFromTheCountryisGreaterThan(int noofdays)
{
	int days = this.getResidencyOutsideKSA().getNoOfDaysOutsideKSA();
	if (days > noofdays)
	{
		return true;
	}
	
	return false;
}
    


public boolean appealTypeDoesntExistInAppeals(AppealType appealType)
{
	List<Appeal> appealsList = this.getAppeals();
	 
	if ( appealsList != null){
		for (Appeal appeal : appealsList)  {
			AppealType personAppealType = appeal.getAppealType();
			if(personAppealType.equals(appealType)) {
				return false;
	    	}
		}
		
	}
	return true;
}
// rename isTheAppealExpired  
public boolean appealISExpired(AppealType appealType)
{
	List<Appeal> appealsList = this.getAppeals();
	Calendar todaysHijriDate = Utilities.getTodaysHigriDate();
	if ( appealsList != null){
		for (Appeal appeal : appealsList)  {
			if(appeal.getAppealType().equals(appealType)){
				
				Calendar appealExpirationDate = appeal.getAppealExpirationDate();
				int days = Utilities.getNumberOfDaysBetweenTwoHijriDates(todaysHijriDate,appealExpirationDate);
				if(days <= 0){
					return true;
				}
			}
			
		}
		
	}
	return false;	
}

    ////////////////////////////////////////////////////////////
	public boolean isDeceased()
	{
		VitalityDetails vitality = getVitalityStatus();
			if ( vitality.isDeceased())
			{
				return true;
			}
		return false;
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public boolean ageIsBetween(int a, int b)
	{
		int age = this.getAge();
		if ( age > a && age < b)
		{
			return true;
		}
		return false;
	}
	
	public boolean ageMoreThan(int number)
	{
		int age = this.getAge();
		if ( age > number )
		{
			return true;
		}
		return false;
	}
	
	public boolean underTheApplicantCustody(Applicant applicant)
    {
		if (this.getGuardianshipstatus().getGuardianNIN() != "" && applicant.getNIN()!= "" )
		{
    		if ( this.getGuardianshipstatus().getGuardianNIN().equals(applicant.getNIN())){
    			return true;
    		} 
		}return false;
    }
	
	public boolean NotUnderTheApplicantCustody(Applicant applicant)
    {
		if (this.getGuardianshipstatus().getGuardianNIN() != "" || applicant.getNIN()!= "" )
		{
    		if ( this.getGuardianshipstatus().getGuardianNIN().equals(applicant.getNIN())){
    			return false;
    		} 
		}return true;
    }
	
	public boolean isEmployed(){
		ArrayList<IncomeDetails> incomeDetails = this.getIncomeDetails();
		if(incomeDetails != null){
			for (IncomeDetails incomeDetail : incomeDetails) {
				if(incomeDetail.getIncomeType().equals(IncomeType.Salary)){
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean totalApplicantSalaryIsMoreThan(int threshold){
		int sum = 0;
		ArrayList<IncomeDetails> incomeDetails = this.getIncomeDetails();
		if(incomeDetails != null){
			for (IncomeDetails incomeDetail : incomeDetails) {
				sum += incomeDetail.getIncomeAmount();
			}
		}
		if(sum > threshold){
			return true;
		}
		return false;
	}
	public RejectionMessages getRejectionMessages() {
		return rejectionMessages;
	}

	public void setRejectionMessages(RejectionMessages rejectionMessages) {
		this.rejectionMessages = rejectionMessages;
	}
	///////////////////////////////////////////////////////////// End Of Class ///////////////////////////////////////////////////////////////////
//	public List<RejectionMessages> getRejectionMessagesObjects() {
//		return RejectionMessagesObjects;
//	}
//	public void setRejectionMessagesObjects(
//			List<RejectionMessages> rejectionMessagesObjects) {
//		RejectionMessagesObjects = rejectionMessagesObjects;
//	}
}
