package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Calendar;

import com.sumerge.ummalqura.calendar.UmmalquraCalendar;

public class PersonalStatusDetails {
	
	public enum StatusDetails
	{
		Addict,
		AddictHusband,
		AddictFather,
		Absent,
		AbsentFather,
		AbsentHusband,
		LostHusband,
		AbandonedOrSuspendend,
		Incapacitated,
		IncapacitatedFather,
		IncapacitatedHusband,
		Handicapped,
		Unknown,
		unknownFather,
		None
	}
	
	private StatusDetails statusDetails = StatusDetails.None;
	private Calendar statusDate = Calendar.getInstance();
	private Calendar statusReportDate = Calendar.getInstance();
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	
	
	////////////////////// Constructor, Setters and getters ///////////////////////////
	
	public PersonalStatusDetails(){}
	public PersonalStatusDetails(@BusinessName("statusDetails") StatusDetails statusDetails, @BusinessName("statusDate") Calendar statusDate,
			@BusinessName("statusReportDate") Calendar statusReportDate, @BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.statusDetails = statusDetails;
		this.statusDate = statusDate;
		this.statusReportDate = statusReportDate;
		this.sourcesMap = sourcesMap;
	}
	
	public StatusDetails getStatusDetails() {
		return statusDetails;
	}


	public void setStatusDetails(StatusDetails statusDetails) {
		this.statusDetails = statusDetails;
	}


	public Calendar getStatusDate() {
		Calendar statusDateHijriDate = Utilities.getHijriDateFromGregorianDate(statusDate);
		int year = statusDateHijriDate.get(Calendar.YEAR);
		int month = statusDateHijriDate.get(Calendar.MONTH);
		int day = statusDateHijriDate.get(Calendar.DAY_OF_MONTH);
		
		return statusDateHijriDate;
	}


	public void setStatusDate(Calendar statusDate) {
		Calendar cal = new UmmalquraCalendar();
		int year = statusDate.get(Calendar.YEAR);
    	int month = statusDate.get(Calendar.MONTH);
    	int day = statusDate.get(Calendar.DAY_OF_MONTH);
    	
    	cal.set(Calendar.YEAR, year);
    	cal.set(Calendar.MONTH, month);
    	cal.set(Calendar.DAY_OF_MONTH, day);
    	
		this.statusDate.setTime(cal.getTime());
	}


	public Calendar getStatusReportDate() {
		Calendar statusReportDateHijriDate = Utilities.getHijriDateFromGregorianDate(statusReportDate);
		int year = statusReportDateHijriDate.get(Calendar.YEAR);
		int month = statusReportDateHijriDate.get(Calendar.MONTH);
		int day = statusReportDateHijriDate.get(Calendar.DAY_OF_MONTH);
		
		return statusReportDateHijriDate;
	}


	public void setStatusReportDate(Calendar statusReportDate) {
		Calendar cal = new UmmalquraCalendar();
		int year = statusReportDate.get(Calendar.YEAR);
    	int month = statusReportDate.get(Calendar.MONTH);
    	int day = statusReportDate.get(Calendar.DAY_OF_MONTH);
    	
    	cal.set(Calendar.YEAR, year);
    	cal.set(Calendar.MONTH, month);
    	cal.set(Calendar.DAY_OF_MONTH, day);
    	
		this.statusReportDate.setTime(cal.getTime());
	}


	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}


	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	
	
	

	
	

}
