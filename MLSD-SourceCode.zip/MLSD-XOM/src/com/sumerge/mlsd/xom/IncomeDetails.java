package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;

public class IncomeDetails {
	
	public enum IncomeType{
		Salary, Pension, PrivateBusiness, Other
	}
	
	private Double incomeAmount = 0.0;
	private String incomeSource = "";
	private IncomeType incomeType = IncomeType.Other;


	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	
	
	public IncomeDetails(){}
	public IncomeDetails(@BusinessName("incomeAmount") Double incomeAmount, @BusinessName("incomeSource") String incomeSource,
			@BusinessName("incomeType") IncomeType incomeType,
			@BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.incomeAmount = incomeAmount;
		this.incomeType = incomeType;
		this.incomeSource = incomeSource;
		this.sourcesMap = sourcesMap;
	}
	public Double getIncomeAmount() {
		return incomeAmount;
	}
	public void setIncomeAmount(Double incomeAmount) {
		this.incomeAmount = incomeAmount;
	}
	public String getIncomeSource() {
		return incomeSource;
	}
	public void setIncomeSource(String incomeSource) {
		this.incomeSource = incomeSource;
	}
	public IncomeType getIncomeType() {
		return incomeType;
	}
	public void setIncomeType(IncomeType incomeType) {
		this.incomeType = incomeType;
	}
	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}
	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	
	
	
	
}

