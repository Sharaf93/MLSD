package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;
import java.util.Date;


public class BenefitDetails {

	private boolean isDependent = false;
	private beneficiaryType benefitType = beneficiaryType.None;
	private Date benefitStartDate = new Date();
	private Date lastPaymentDate = new Date();
	private String beneficiarySegment = "";
	
	public enum beneficiaryType{
		SocialSecurity, Subsidy, None
	}
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();

	public BenefitDetails(){}
	public BenefitDetails(@BusinessName("isDependent") boolean isBeneficiary, @BusinessName("benefitStartDate")Date benefitStartDate,
			@BusinessName("lastPaymentDate") Date lastpaymentdate, @BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.isDependent = isBeneficiary;
		this.benefitStartDate = benefitStartDate;
		this.lastPaymentDate = lastpaymentdate;
		this.sourcesMap = sourcesMap;
	}

	public boolean isDependent() {
		return isDependent;
	}

	public void setDependent(boolean isBeneficiary) {
		this.isDependent = isBeneficiary;
	}

	public Date getBenefitStartDate() {
		return benefitStartDate;
	}

	public void setBenefitStartDate(Date benefitStartDate) {
		this.benefitStartDate = benefitStartDate;
	}

	public String getBeneficiarySegment() {
		return beneficiarySegment;
	}

	public void setBeneficiarySegment(String beneficiarySegment) {
		this.beneficiarySegment = beneficiarySegment;
	}

	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}

	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}
	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}
	public beneficiaryType getBenefitType() {
		return benefitType;
	}
	public void setBenefitType(beneficiaryType benefitType) {
		this.benefitType = benefitType;
	}
	
	
}
