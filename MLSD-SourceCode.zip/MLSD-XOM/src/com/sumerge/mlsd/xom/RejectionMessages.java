package com.sumerge.mlsd.xom;

import java.util.ArrayList;
import java.util.List;

public class RejectionMessages {
	
private List<RejectionMessageDetails> rejectionMsg = new ArrayList<RejectionMessageDetails>();	
	
	public RejectionMessages(){}

	public List<RejectionMessageDetails> getRejectionMsg() {
		return rejectionMsg;
	}

	public void setRejectionMsg(List<RejectionMessageDetails> rejectionMsg) {
		this.rejectionMsg = rejectionMsg;
	}
}
