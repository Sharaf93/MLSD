package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;

import java.util.ArrayList;

public class EducationDetails {
	
	public enum EducationLevel{
		school, kindergarden, TransientCard
	}
	
	private String educationalLevel = "";
	private boolean isStudent = false;
	
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	
	///////////////////////////////////////////////////////////////////////////////
	public EducationDetails(){}
	public EducationDetails(@BusinessName("EducationLevel") String educationalLevel, @BusinessName("isStudent") boolean isStudent,
			@BusinessName("sourcesMap") ArrayList<SourceMapper> sourcesMap) {
		super();
		this.educationalLevel = educationalLevel;
		this.isStudent = isStudent;
		this.sourcesMap = sourcesMap;
	}


	public String getEducationalLevel() {
		return educationalLevel;
	}

	public void setEducationalLevel(String educationalLevel) {
		this.educationalLevel = educationalLevel;
	}

	public boolean isStudent() {
		return isStudent;
	}

	public void setStudent(boolean isStudent) {
		this.isStudent = isStudent;
	}

	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}

	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	
	
	

}
