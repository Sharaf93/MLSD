package com.sumerge.mlsd.xom;

import ilog.rules.bom.annotations.BusinessName;
import ilog.rules.engine.IlrDefaultCollector;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.sumerge.mlsd.xom.IncomeDetails.IncomeType;
import com.sumerge.ummalqura.calendar.UmmalquraCalendar;


public class Applicant extends Person{
	
	public enum Segment{
		Family, Independent
	}

	private boolean eligibilityStatus= true;
	private Date applicationDate = new Date();
	private Person mother = new Person();
	private Person father = new Person();
	private Person husband = new Person();
	private ArrayList<Person> wives = new ArrayList<Person>();
	private ArrayList<Person> siblings = new ArrayList<Person>();
	private ArrayList<Person> offsprings = new ArrayList<Person>();
	private List<Person> eligibleDependents = new ArrayList<Person>();
	private List<Person> ineligibleDependents = new ArrayList<Person>();
	private ArrayList<Person> underCustody = new ArrayList<Person>();
	private ArrayList<SourceMapper> sourcesMap = new ArrayList<SourceMapper>();
	
	//private RejectionMessages rejectionMessages = new RejectionMessages();
	
	private Calendar registrationDate = Calendar.getInstance();
	
	private ArrayList<Person> applicableDependents = new ArrayList<Person>();
	private List<Person> notApplicableDependents = new ArrayList<Person>();
	
/////////////////////////////Constructors, setters and getters//////////////////////
	
	public Applicant(){}
	
	
	public Applicant(@BusinessName("age") int age, @BusinessName("NIN") String NIN, @BusinessName("ID") String iD,/* @BusinessName("IDType") String iDType,*/ @BusinessName("name") String name,
			@BusinessName("gender") Gender gender,/* @BusinessName("maritalStatus") String maritalStatus, @BusinessName("nationality") String nationality,*/
			@BusinessName("livesInGovernmentHouse") boolean livesInGovernmentShelter, @BusinessName("hasAPrivateBusiness") boolean hasAPrivateBusiness,
			@BusinessName("approvedToBeIndependentFromBeneficiary") boolean approvedToBeIndependentFromBeneficiary, @BusinessName("isBlacklisted") boolean isBlacklisted,
			@BusinessName("vitalityStatus") VitalityDetails vitalityStatus, @BusinessName("benefitDetails") BenefitDetails benefitDetails,
			@BusinessName("educationDetails") EducationDetails profession, @BusinessName("statusDetails") PersonalStatusDetails statusDetails,
			@BusinessName("residencyDetailsOutsideKSA") ResidencyDetailsOutsideKSA residency, @BusinessName("imprisonmentDetails")  ImprisonmentDetails imprisonment,
			@BusinessName("medicalCondition") MedicalCondition medicalCondition, @BusinessName("incomeDetails") ArrayList<IncomeDetails> employments,
			@BusinessName("homeWorkers") ArrayList<HomeWorkerDetails> homeWorkers,
			@BusinessName("commercialWorkers") ArrayList<CommercialWorkerDetails> commercialWorkers, @BusinessName("appeals") ArrayList<Appeal> appeals,@BusinessName("assets") ArrayList<AssetDetails> assets,
			@BusinessName("personsourcesMap") ArrayList<SourceMapper> sourcesMap, @BusinessName("hasCommercialRecord") boolean hasCommercialRecord,
			@BusinessName("applicationDate") Date applicationDate, @BusinessName("mother") Person mother, @BusinessName("father") Person father, @BusinessName("siblings") ArrayList<Person> siblings,
			@BusinessName("wives") ArrayList<Person> wives, @BusinessName("offsprings") ArrayList<Person> offsprings, @BusinessName("husband") Person husband,
			@BusinessName("sourcesMap2") ArrayList<SourceMapper> sourcesMap2,@BusinessName("registrationDate") Date subsidyRegistrationDate){
		super(age, NIN, iD, name, gender, livesInGovernmentShelter,
				hasAPrivateBusiness, approvedToBeIndependentFromBeneficiary,
				isBlacklisted, vitalityStatus, benefitDetails, profession,
				statusDetails, residency, imprisonment, medicalCondition, employments,
				homeWorkers, commercialWorkers, appeals,assets , sourcesMap);
		// TODO Auto-generated constructor stub 
	}

	
	public Person getMother() {
		return mother;
	}

	public void setMother(Person mother) {
		this.mother = mother;
	}

	public Person getFather() {
		return father;
	}

	public void setFather(Person father) {
		this.father = father;
	}

	public ArrayList<Person> getSiblings() {
		return siblings;
	}

	public void setSiblings(ArrayList<Person> siblings) {
		this.siblings = siblings;
	}

	public ArrayList<Person> getWives() {
		return wives;
	}


	public void setWives(ArrayList<Person> wives) {
		this.wives = wives;
	}


	public ArrayList<Person> getOffsprings() {
		return offsprings;
	}


	public void setOffsprings(ArrayList<Person> offsprings) {
		this.offsprings = offsprings;
	}


	public Person getHusband() {
		return husband;
	}


	public void setHusband(Person husband) {
		this.husband = husband;
	}

	public ArrayList<Person> getUnderCustody() {
		return underCustody;
	}


	public void setUnderCustody(ArrayList<Person> underCustody) {
		this.underCustody = underCustody;
	}


	public Calendar getSubsidyRegistrationDate() {
		Calendar subsidyRegistrationHijriDate = Utilities.getHijriDateFromGregorianDate(registrationDate);
		return subsidyRegistrationHijriDate;
	}
	public ArrayList<Person> getApplicableDependents() {
		return applicableDependents;
	}


	public void setApplicableDependents(ArrayList<Person> applicableDependents) {
		this.applicableDependents = applicableDependents;
	}


	public void setSubsidyRegistrationDate(Calendar subsidyRegistrationDate) {
		
		Calendar cal = new UmmalquraCalendar();
		int year = subsidyRegistrationDate.get(Calendar.YEAR);
    	int month = subsidyRegistrationDate.get(Calendar.MONTH);
    	int day = subsidyRegistrationDate.get(Calendar.DAY_OF_MONTH);
    	cal.set(Calendar.YEAR, year);
    	cal.set(Calendar.MONTH, month);
    	cal.set(Calendar.DAY_OF_MONTH, day);
    	
		this.registrationDate.setTime(cal.getTime());
	}
	
	public Date getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	public ArrayList<SourceMapper> getSourcesMap() {
		return sourcesMap;
	}
	public void setSourcesMap(ArrayList<SourceMapper> sourcesMap) {
		this.sourcesMap = sourcesMap;
	}
	
//////////////////////////////////////////// Added functions /////////////////////////////////////////////////
	

	public List<Person> getEligibleDependents() {
		if(this.eligibleDependents == null){
			this.eligibleDependents = new ArrayList<Person>();
		}
		return eligibleDependents;
	}
	public List<Person> getIneligibleDependents() {
		if(this.ineligibleDependents == null){
			this.ineligibleDependents = new ArrayList<Person>();
		}
		return this.ineligibleDependents;
	}


	public void setIneligibleDependents(List<Person> ineligibleDependents) {
		this.ineligibleDependents = ineligibleDependents;
	}


	public void setEligibleDependents(List<Person> dependents) {
		this.eligibleDependents = dependents;
	}
	
	public String getRejectionMessage() {
		return "";
	}


    ////////////////////////////////////////////////////////////////////////////////////////-
	// isReasonValidityDateDidNotExceedOneYear
    public boolean TheReasonValidityDateForTheApprovalDidNotExceedOneYear()
    {
    	int days = daysBetween(Calendar.getInstance().getTime(), this.getResidencyOutsideKSA().getReasonValidityDate());
    	if (days < 366)
    	{
    		return true;
    	}
    	return false;
    }
    ////////////////////////////
    public boolean registrationDateIsMoreThan(int noofdays){
    	
    	Calendar todaysHijriDate = Utilities.getTodaysHigriDate();
    	int days = Utilities.getNumberOfDaysBetweenTwoHijriDates(this.getSubsidyRegistrationDate(), todaysHijriDate);
    	
    	if (days > noofdays)
    	{
    		return true;
    	}
    	
    	return false;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    @SuppressWarnings("unchecked")
	public void addToIneligibleDependents(ilog.rules.engine.IlrDefaultCollector toBeAdded )
    {
    	
		List<Person> toAdd = new ArrayList<Person>(toBeAdded);
    	
    	
    	if (toAdd != null)
    	{
    		List<Person> tempDependents = getIneligibleDependents();
    		for (int i = 0; i < toAdd.size(); i++) 
        	{
        		tempDependents.add(toAdd.get(i));
    		}
    	}    	
    }
    
    @SuppressWarnings("unchecked")
   	public void addToNotApplicableDependents(ilog.rules.engine.IlrDefaultCollector toBeAdded )
       {
       	
   		List<Person> toAdd = new ArrayList<Person>(toBeAdded);
       	if (toAdd != null)
       	{
       		List<Person> tempDependents = getNotApplicableDependents();
       		for (int i = 0; i < toAdd.size(); i++) 
           	{
       			if(!tempDependents.contains(toAdd.get(i))){
       				tempDependents.add(toAdd.get(i));
       			}
       		}
       	}    	
       }
    
    @SuppressWarnings("unchecked")
	public void addToEligibleDependents(ilog.rules.engine.IlrDefaultCollector toBeAdded )
    {
    	
		List<Person> toAdd = new ArrayList<Person>(toBeAdded);
    	
    	
    	if (toAdd != null)
    	{
    		List<Person> tempDependents = getEligibleDependents();
    		for (int i = 0; i < toAdd.size(); i++) 
        	{
        		tempDependents.add(toAdd.get(i));
    		}
    		setEligibleDependents(tempDependents);
    	}    	
    }
    // isGuardianToPerson
    public boolean theGuardianIsTheApplicant(Person person)
    {
    	if(person != null){
    		GuardianshipStatus guardianshipStatus = person.getGuardianshipstatus();
    		if(guardianshipStatus != null && this.getNIN() != "")
    		{
    			if(guardianshipStatus.getGuardianNIN().equals(this.getNIN()))
    			{
    				return true;
    			}
    		}
    	}
    	
    	return false;
    }
    // isntGuardianToPerson .... delete and reverbalize above func
    public boolean theGuardianIsNotTheApplicant(Person person)
    {
    	GuardianshipStatus guardianshipStatus;
    	if(person != null){
    		guardianshipStatus = person.getGuardianshipstatus();
    		if(guardianshipStatus != null && this.getNIN() != "")
    		{
    			if(guardianshipStatus.getGuardianNIN().equals(this.getNIN()) )
    			{
    				return false;
    			}
    		}
    	}
    	
    	return true;
    }
    
    /// Add person to dependents
    public void addPersonToEligibleDependents(Person person)
    {
    	if (person.getNIN() != null && person.getNIN() != "")
    	{
    		this.getEligibleDependents().add(person);
    		
    	}    	
    }
   
    public void addPersonToIneligibleDependents(Person person)
    {
    	if (person.getNIN() != null && person.getNIN() != "")
    	{
    		this.getIneligibleDependents().add(person);
    		
    	}    	
    }
    
    public void addPersonToApprovedDependents(Person person)
    {
    	if (person != null)
    	{
    		this.getEligibleDependents().add(person);
    		
    	}    	
    }
   
    public void addPersonToNotApprovedDependents(Person person)
    {
    	if (person != null)
    	{
    		this.getIneligibleDependents().add(person);
    		
    	}    	
    }
    // for each
    @SuppressWarnings("unchecked")
	public void removeFromEligibleDependents(ilog.rules.engine.IlrDefaultCollector toBRemoved )
    {
    	
    	ArrayList<Person> toBeRemoved = new ArrayList<Person>(toBRemoved);
    	List<Person> tempDependents = new ArrayList<Person>();
    	tempDependents = getEligibleDependents();
    	
    	if (toBeRemoved != null)
    	{
    		for (int i = 0; i < toBeRemoved.size(); i++) 
        	{
        	
        		if( tempDependents.contains(toBeRemoved.get(i)) )
        		{
        			tempDependents.remove(toBeRemoved.get(i));
        		}
    		}
    		
    	}
    	setEligibleDependents(tempDependents);
    }
    
    public void removeAPersonFromTheEligibleDependents(Person toBeRemoved){
    	List<Person> tempDependents = new ArrayList<Person>();
    	tempDependents = this.getEligibleDependents();
    	
    	if (toBeRemoved != null && tempDependents != null){
			if(tempDependents.contains(toBeRemoved)){
				tempDependents.remove(toBeRemoved);
			}
    	}
    	this.setEligibleDependents(tempDependents);
    }
    
    @SuppressWarnings("unchecked")
	public void removeFromSiblings(ilog.rules.engine.IlrDefaultCollector toBRemoved)
    {
    	
    	ArrayList<Person> toBeRemoved = new ArrayList<Person>(toBRemoved);
    	ArrayList<Person> dependentsToRemoveFrom = this.getSiblings();    	
    	if (toBeRemoved != null && dependentsToRemoveFrom != null)
    	{
    		for (int i = 0; i < toBeRemoved.size(); i++) 
        	{
        		if( dependentsToRemoveFrom.contains(toBeRemoved.get(i)) )
        		{
        			dependentsToRemoveFrom.remove(toBeRemoved.get(i));
        		}
    		}
    	}
    }
    @SuppressWarnings("unchecked")
	public void removeFromUnderCustody(ilog.rules.engine.IlrDefaultCollector toBRemoved)
     {
        	
        	ArrayList<Person> toBeRemoved = new ArrayList<Person>(toBRemoved);
        	ArrayList<Person> dependentsToRemoveFrom = this.getUnderCustody();    	
        	if (toBeRemoved != null && dependentsToRemoveFrom != null)
        	{
        		for (int i = 0; i < toBeRemoved.size(); i++) 
            	{
            		if( dependentsToRemoveFrom.contains(toBeRemoved.get(i)) )
            		{
            			dependentsToRemoveFrom.remove(toBeRemoved.get(i));
            		}
        		}
        	}
    	setUnderCustody(dependentsToRemoveFrom);
    }
    	
    @SuppressWarnings("unchecked")
	public void removeFromWives(ilog.rules.engine.IlrDefaultCollector toBRemoved)
    {
    	
    	ArrayList<Person> toBeRemoved = new ArrayList<Person>(toBRemoved);
    	ArrayList<Person> dependentsToRemoveFrom = this.getWives();    	
    	if (toBeRemoved != null && dependentsToRemoveFrom != null)
    	{
    		for (int i = 0; i < toBeRemoved.size(); i++) 
        	{
        		if( dependentsToRemoveFrom.contains(toBeRemoved.get(i)) )
        		{
        			dependentsToRemoveFrom.remove(toBeRemoved.get(i));
        		}
    		}
    	}
    	setWives(dependentsToRemoveFrom);
    }
    @SuppressWarnings("unchecked")
	public void removeFromOffsprings(ilog.rules.engine.IlrDefaultCollector toBRemoved)
    {
    	
    	ArrayList<Person> toBeRemoved = new ArrayList<Person>(toBRemoved);
    	ArrayList<Person> dependentsToRemoveFrom = this.getOffsprings();    	
    	if (toBeRemoved != null && dependentsToRemoveFrom != null)
    	{
    		for (int i = 0; i < toBeRemoved.size(); i++) 
        	{
        		if( dependentsToRemoveFrom.contains(toBeRemoved.get(i)) )
        		{
        			dependentsToRemoveFrom.remove(toBeRemoved.get(i));
        		}
    		}
    	}
    	setOffsprings(dependentsToRemoveFrom);
    }
    
    // get offsprings with no dependents
    public List<Person> getOffspringsWithNoOffspringsUnderCustody()
    {
    	List<Person> offsprings = this.getOffsprings();
    	List<Person> undercustody = this.getUnderCustody();
    	List<Person> offspringsWithNoCustodyOffsprings = offsprings;
    	
    	if(offsprings != null && undercustody != null)
    	{
    		for (Person person : offsprings) {
        		
        		for (Person custodyperson : undercustody) {
        			
    				if(custodyperson.getGuardianshipstatus().getGuardianNIN().equals(person.getNIN()))
    				{
    					offspringsWithNoCustodyOffsprings.remove(person);
    				}
    			}
    			
    		}
    	}
    	return offspringsWithNoCustodyOffsprings;
    } 
    
    public double getTotalFamilyIncome(){
    	double total = 0;
    	List<Person> dependents = this.getEligibleDependents();
    	
    	/////////////////////  Dependents ///////////////////////////
    	if(dependents != null){
    		for (Person person : dependents) {
    			List<IncomeDetails> dependentIncomeDetails =  person.getIncomeDetails();
    			if(dependentIncomeDetails != null){
    				for (IncomeDetails incomeDetail : dependentIncomeDetails) {
        				total += incomeDetail.getIncomeAmount();
        			}
    			}
    		}
    	}
    	/////////////////////////   Applicant   /////////////////////////////////
    	List<IncomeDetails> applicantIncomeDetails = this.getIncomeDetails();
    	if(applicantIncomeDetails != null){
    		for (IncomeDetails applicantIncomeDetail : applicantIncomeDetails) {
        		total += applicantIncomeDetail.getIncomeAmount();
    		}
    	}
    	total = Math.round(total * 100);
    	total = total / 100;
    	return total;
	}   
    
    ////////////////////////////////////////////////////////////////////////////
    
    public double getTotalApplicantIncome(){
    	
    	double total = 0;
    	List<IncomeDetails> applicantIncomeDetails = this.getIncomeDetails();
    	if(applicantIncomeDetails != null){
    		for (IncomeDetails applicantIncomeDetail : applicantIncomeDetails) {
        		total += applicantIncomeDetail.getIncomeAmount();
    		}
    	}
    	total = Math.round(total * 100);
    	total = total / 100;
    	System.out.println("total Income: " + total);
    	return total;
	} 
    //////////////////////////////////////////////////////////////////////////
    // no "the"
    public boolean theApplicantIsEligible()
    {
    	return this.eligibilityStatus;
    }
    
    // mark applicant as eligible
    public void setTheApplicantasEligible()
    {
    	//TODO: remove parameter
    	this.eligibilityStatus = true;
    }
    public void setTheApplicantasNotEligible()
    {
    	this.eligibilityStatus = false;
    }
    
    public boolean temporaryDisabilityMedicationPeriodCheck(){
		Calendar today = Calendar.getInstance();
		Calendar medicalReportDate = this.getMedicalCondition().getMedicalReportDate();
		int medicationPeriod = this.getMedicalCondition().getMedicationPeriod();
		
		int daysBetweenTodayAndReport =  daysBetween(medicalReportDate.getTime(),today.getTime());
		int difference = medicationPeriod - daysBetweenTodayAndReport;
		if(difference > 0){
			return true; // Greater than todays date
		}
		return false; // Less than todays date
	}
	
	public boolean permenantDisabilityReportExpirationCheck(int years){
		Calendar today = Calendar.getInstance();
		Calendar medicalReportDate = this.getMedicalCondition().getMedicalReportDate();
		int reportYear = medicalReportDate.get(Calendar.YEAR);
		int expirationYear = reportYear + years;
		medicalReportDate.set(Calendar.YEAR, expirationYear);
		
		int daysBetweenTodayAndReportExp = daysBetween(today.getTime(),medicalReportDate.getTime());
		if(daysBetweenTodayAndReportExp > 0){
			return true; // Greater than todays date
		}
		return false; // Less than todays date
	}
    /**
	 * @return the rejectionMessages
	 */
	public boolean isAnEmployee(){
		ArrayList<IncomeDetails> incomeDetails = this.getIncomeDetails();
		if(incomeDetails != null){
			for (IncomeDetails incomeDetail : incomeDetails) {
				if(incomeDetail.getIncomeType().equals(IncomeType.Salary)){
					return true;
				}
			}
		}
		return false;
	}
	
	public ArrayList<Person> getOffspringsAndSiblings(){
		ArrayList<Person> offsprings = this.getOffsprings();
		ArrayList<Person> siblings = this.getSiblings();
		ArrayList<Person> offspringsAndSiblings = new ArrayList<Person>();
		
		offspringsAndSiblings.addAll(offsprings);
		offspringsAndSiblings.addAll(siblings);
		
		return offspringsAndSiblings;
	}
	
	public void addPersonToTheApplicableDependents(Person person)
    {
    	if (person != null)
    	{
    		this.getApplicableDependents().add(person);
    	}    	
    }
	@SuppressWarnings("unchecked")
	public void addAllPeopleToTheApplicableDependents(ilog.rules.engine.IlrDefaultCollector people)
    {
    	if (people != null)
    	{
    		this.getApplicableDependents().addAll(people);
    	}    	
    }
	
//	public ilog.rules.engine.IlrDefaultCollector InEligibleAssetDependents(){
//		ArrayList<Person> dependents = (ArrayList<Person>) this.getEligibleDependents();
//		IlrDefaultCollector notEligibleDependents = new IlrDefaultCollector();
//		if(dependents != null){
//			ArrayList<AssetDetails> assetDetails = new ArrayList<AssetDetails>();
//			int residentialAsset;
//			int grantedFromStateAsset;
//			int area;
//			boolean flag;
// 			for (Person person : dependents) {
//				assetDetails = person.getAssets();
//				if(assetDetails != null){
//					residentialAsset = 0;
//					grantedFromStateAsset = 0;
//					area = 0;
//					flag = false;
//					for (AssetDetails assetDetail : assetDetails) {
//						if(assetDetail.isNotShared() && assetDetail.isNotCommercial()){
//							residentialAsset++;
//						}
//						String sourceOfAsset = assetDetail.getSourceOfAsset();
//						if(sourceOfAsset != null){
//							if(sourceOfAsset.equals("Granted From State")){
//								grantedFromStateAsset++;
//								area = assetDetail.getArea();
//							}
//						}
//					}
//					if(residentialAsset > 1 || grantedFromStateAsset > 1){
//						flag = true;
//					}
//					if(grantedFromStateAsset == 1 && flag == false){
//						if(area > 2000){
//							flag = true;
//						}
//					}
//					if(flag == true){
//						notEligibleDependents.add(person);
//					}
//				}
//			}
//		}
//		return notEligibleDependents;
//	}
	
	public ilog.rules.engine.IlrDefaultCollector InEligibleAssetDependents(){
		ArrayList<Person> dependents = (ArrayList<Person>) this.getEligibleDependents();
		IlrDefaultCollector notEligibleDependents = new IlrDefaultCollector();
		if(dependents != null){
			ArrayList<AssetDetails> assetDetails = new ArrayList<AssetDetails>();
			int residentialAsset;
			int grantedFromStateAsset;
			int area;
			boolean flag;
 			for (Person person : dependents) {
				assetDetails = person.getAssets();
				if(assetDetails != null){
					residentialAsset = 0;
					grantedFromStateAsset = 0;
					area = 0;
					flag = false;
					for (AssetDetails assetDetail : assetDetails) {
						if((assetDetail.isNotShared() && assetDetail.isNotCommercial()) ||( 
								assetDetail.getSourceOfAsset().equals("Residential"))){
							residentialAsset++;
						}
						String sourceOfAsset = assetDetail.getSourceOfAsset();
						if(sourceOfAsset != null){
							if(sourceOfAsset.equals("Granted From State")){
								grantedFromStateAsset++;
								area = assetDetail.getArea();
							}
						}
					}
					if(residentialAsset > 1 || grantedFromStateAsset > 1){
						flag = true;
					}
					if(grantedFromStateAsset == 1 && flag == false){
						if(area > 2000){
							flag = true;
						}
					}
					if(flag == true){
						notEligibleDependents.add(person);
					}
				}
			}
		}
		return notEligibleDependents;
	}
	
	public ilog.rules.engine.IlrDefaultCollector InEligibleNationalityDependents(){
		ArrayList<Person> dependents = (ArrayList<Person>) this.getEligibleDependents();
		ilog.rules.engine.IlrDefaultCollector ineligibleDependents = new IlrDefaultCollector();
		if(dependents != null){
			boolean flag;
			for (Person person : dependents) {
				String nationality = person.getNationality();
				String idType = person.getIDType();
				flag = false;
				if(nationality == null && idType == null){
					flag = true;
				}
				else if(nationality != null && idType != null){
					if(!(nationality.equals("Saudi Arabia")) && !(nationality.equals("Transient")) && 
							!(idType.equals("Transient Card"))){
								flag = true;
					}
				}
				else{
					if(nationality != null){
						if(!(nationality.equals("Saudi Arabia")) && !(nationality.equals("Transient"))){
									flag = true;
						}
					}
					if(idType != null && flag == false){
						if(!(idType.equals("Transient Card"))){
									flag = true;
						}
					}
				}
				if(flag == true){
					ineligibleDependents.add(person);
				}
			}
		}
		return ineligibleDependents;
	}

	public ilog.rules.engine.IlrDefaultCollector InEligibleCommercialWorkersDependents(){
		ArrayList<Person> dependents = (ArrayList<Person>) this.getEligibleDependents();
		ilog.rules.engine.IlrDefaultCollector ineligibleDependents = new IlrDefaultCollector();
		if(dependents != null){
			ArrayList<CommercialWorkerDetails> commercialWorkers = new ArrayList<CommercialWorkerDetails>();
			for (Person person : dependents) {
				commercialWorkers = person.getCommercialWorkers();
				if(commercialWorkers.size() > 0){
					ineligibleDependents.add(person);
				}
			}
		}
		return ineligibleDependents;
	}
	
	public ilog.rules.engine.IlrDefaultCollector InEligibleHomeLaborDependents(){
		ArrayList<Person> dependents = (ArrayList<Person>) this.getEligibleDependents();
		ilog.rules.engine.IlrDefaultCollector ineligibleDependents = new IlrDefaultCollector();
		if(dependents != null){
			boolean flag;
			int Nurses;
			ArrayList<HomeWorkerDetails> homeworkers = new ArrayList<HomeWorkerDetails>();
			for (Person person : dependents) {
				homeworkers = person.getHomeWorkers();
				flag = false;
				Nurses = 0;
				if(homeworkers.size() > 3){
					flag = true;
				}
				else{
					if(homeworkers.size() == 3){
						String typeOfFirstWorker = homeworkers.get(0).getTypeOfWork();
						String typeOfSecondWorker = homeworkers.get(1).getTypeOfWork();
						String typeOfThirdWorker = homeworkers.get(2).getTypeOfWork();
						if(typeOfFirstWorker.equals("Nurse")){
							Nurses++;
						}
						if(typeOfSecondWorker.equals("Nurse")){
							Nurses++;
						}
						if(typeOfThirdWorker.equals("Nurse")){
							Nurses++;
						}
						if(typeOfFirstWorker.equals(typeOfSecondWorker) || typeOfFirstWorker.equals(typeOfThirdWorker) ||
								typeOfSecondWorker.equals(typeOfThirdWorker)){
							flag = true;
						}
						if(Nurses == 0 || Nurses > 1){
							flag = true;
						}
						if(Nurses == 1){
							MedicalCondition medical = person.getMedicalCondition();
							if(medical.isTerminallyIll() == false && medical.isPermenantDisability() == false){
								flag = true;
							}
						}
					}
					if(homeworkers.size() == 2){
						String typeOfFirstWorker = homeworkers.get(0).getTypeOfWork();
						String typeOfSecondWorker = homeworkers.get(1).getTypeOfWork();
						if(typeOfFirstWorker.equals(typeOfSecondWorker)){
							flag = true;
						}
					}
				}
				if(flag == true){
					ineligibleDependents.add(person);
				}
			}
		}
		return ineligibleDependents;
	}
	 public boolean hasAddedHusband()
	    {
	    	if(husband.getNIN().equals("") )
	    	{
	    		return false;
	    	}
	    	return true;
	    }
	    
	    public boolean hasAddedFather()
	    {
	    	if(father.getNIN().equals("") )
	    	{
	    		return false;
	    	}
	    	return true;
	    }
	    
	    public boolean hasAddedsMother()
	    {
	    	if(mother.getNIN().equals("") )
	    	{
	    		return false;
	    	}
	    	return true;
	    }
	///////////////// End of Classs ///////////////////////


		public List<Person> getNotApplicableDependents() {
			return notApplicableDependents;
		}


		public void setNotApplicableDependents(List<Person> notApplicableDependents) {
			this.notApplicableDependents = notApplicableDependents;
		}
}
