package com.sumerge.mlsd.xom;

import java.util.Calendar;

import com.sumerge.ummalqura.calendar.UmmalquraCalendar;


public class Appeal {

	public enum AppealType{
		Imprisonment, Alive, Citizenship, NonPermanency, NONE
	}

	private AppealType appealType = AppealType.NONE;
	private Calendar appealExpirationDate = Calendar.getInstance();
	private boolean appealValidity = false;
	
	
	public Appeal(){}
	
	public Appeal(AppealType appealType, Calendar appealExpirationDate, boolean appealValidity) {
		super();
		this.appealType = appealType;
		this.appealExpirationDate = appealExpirationDate;
		this.appealValidity = appealValidity;
	}

	public AppealType getAppealType() {
		return appealType;
	}

	public void setAppealType(AppealType appealType) {
		this.appealType = appealType;
	}

	public Calendar getAppealExpirationDate() {
		Calendar appealExpirationHijriDate = Utilities.getHijriDateFromGregorianDate(appealExpirationDate);
		int year = appealExpirationHijriDate.get(Calendar.YEAR);
		int month = appealExpirationHijriDate.get(Calendar.MONTH);
		int day = appealExpirationHijriDate.get(Calendar.DAY_OF_MONTH);

		return appealExpirationHijriDate;
	}

	public void setAppealExpirationDate(Calendar appealExpirationDate) {
		Calendar cal = new UmmalquraCalendar();
		int year = appealExpirationDate.get(Calendar.YEAR);
    	int month = appealExpirationDate.get(Calendar.MONTH);
    	int day = appealExpirationDate.get(Calendar.DAY_OF_MONTH);
    	
    	cal.set(Calendar.YEAR, year);
    	cal.set(Calendar.MONTH, month);
    	cal.set(Calendar.DAY_OF_MONTH, day);
    	
		this.appealExpirationDate.setTime(cal.getTime());
	}

	public boolean isAppealValidity() {
		return appealValidity;
	}

	public void setAppealValidity(boolean appealValidity) {
		this.appealValidity = appealValidity;
	}
	
	
}
