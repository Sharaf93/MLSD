package com.sumerge.mlsd.xom.socialcare;

import com.sumerge.mlsd.xom.common.Person;

public class ElderlyApplicant extends Person {

	private boolean applicantIsEligible = true;

	public ElderlyApplicant() {
		/*
		 * Empty Constructor for NULL Avoidance
		 */
	}

	public boolean isTheApplicantEligible() {
		return applicantIsEligible;
	}

	public void setTheApplicantAsEligible() {
		this.applicantIsEligible = true;
	}

	public void setTheApplicantAsInEligible() {
		this.applicantIsEligible = false;
	}

	public void setApplicantIsEligible(boolean applicantIsEligible) {
		this.applicantIsEligible = applicantIsEligible;
	}

}
