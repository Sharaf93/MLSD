package com.sumerge.mlsd.xom.socialcare;

import java.util.Calendar;

import com.sumerge.mlsd.utilities.Utilities;

/**
 * The medical equipment of the applicant. Indicating the medical equipment
 * itself and the recieval date of the equipment.
 * 
 * @author Ahmed Sharaf
 *
 */
public class ApplicantMedicalEquipment {

	private Calendar equipmentReceivalDate = Calendar.getInstance();

	private MedicalEquipmentProfile medicalEquipmentDetails = new MedicalEquipmentProfile();

	public ApplicantMedicalEquipment() {
		/*
		 * Empty Constructor for NULL Avoidance
		 */
	}

	public MedicalEquipmentProfile getMedicalEquipmentDetails() {
		return medicalEquipmentDetails;
	}

	public void setMedicalEquipmentDetails(MedicalEquipmentProfile medicalEquipmentDetails) {
		this.medicalEquipmentDetails = medicalEquipmentDetails;
	}

	public Calendar getEquipmentReceivalDate() {
		return equipmentReceivalDate;
	}

	public void setEquipmentReceivalDate(Calendar equipmentReceivalDate) {
		this.equipmentReceivalDate = equipmentReceivalDate;
	}

	public boolean equipmentReceivalDateExceeds(int month) {
		Calendar todaysDate = Calendar.getInstance();
		Calendar receivalDate = this.getEquipmentReceivalDate();
		int monthsDifference = Utilities.getMonthsDifference(receivalDate, todaysDate);
		if (monthsDifference > month) {
			return true; // exceeds the number of month
		} else {
			return false;
		}
	}

}
